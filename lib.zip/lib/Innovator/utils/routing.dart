class Myroutes {
  static const String spalshscreenroute = "/spalshscreen";
  static const String homeroute = "/home";
  static const String bookroute = "/bookspages";
}


class Authenticator{
  static const String loginroute = "/login";
  static const String signuproute = "/signup";
  static const String forgetpwd = '/forgetpwd';
}